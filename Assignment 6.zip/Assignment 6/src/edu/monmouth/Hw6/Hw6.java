package edu.monmouth.Hw6;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.PrintStream;
import java.util.LinkedList;
import java.util.List;
import java.util.PriorityQueue;
import java.util.Properties;

import edu.monmouth.Hw6.BookPrice.BookPrice;
import edu.monmouth.cs205.book.Book;
import edu.monmouth.cs205.book.BookException;
import edu.monmouth.cs205.book.BookTypes;


public class Hw6 
{

	public static void main(String[] args) throws BookException 
	{
		if(args.length != Hw6Constants.REQUIRED_PARAMETERS)
			{
				System.err.println("Supply the properties file name");
				System.exit(Hw6Constants.PARAMETERS_EXIT);
			}
			String propertiesFileName = args[0];
			Properties properties = new Properties();
			try
			{
				properties.load(new FileInputStream(propertiesFileName));
				
			}
			catch (IOException e)
			{
				System.out.println("Cannot locate properties file " + e.getMessage());
				System.exit(Hw6Constants.PROPERTIES_FILE_EXIT);
			}
			properties.list(System.out);
			String logFileName = properties.getProperty(Hw6Constants.LOG_FILE_PROPERTIES_NAME);
			if(logFileName == null)
			{
				System.err.println("Cannot locate property " + Hw6Constants.LOG_FILE_PROPERTIES_NAME);
				System.exit(Hw6Constants.LOG_FILE_EXIT);
			}
			try 
			{
				PrintStream out = new PrintStream(logFileName);
				System.setErr(out);
				System.setOut(out);
			} 
			catch (FileNotFoundException e) 
			{
				System.err.println("Cannot redirect to " + logFileName);
				System.exit(Hw6Constants.LOG_FILE_EXIT);
			} 	
	
		List<Book> bookList = new LinkedList<Book>();
		try {
			BufferedReader reader = new BufferedReader(new FileReader(Hw6Constants.FILENAME));
			String text;
			
			while((text = reader.readLine()) != null)
			{
				String result [] = text.split(Hw6Constants.SEPARATOR);
				
				for(String element: result)
				{
					System.out.println(element);
					
				}

				String title = String.valueOf(result[Hw6Constants.TITLEOFFSET]);
				BookTypes book1 = BookTypes.valueOf(result[Hw6Constants.BOOKTYPEOFFSET]);
				int numOfPages = Integer.parseInt(result[Hw6Constants.NUMBEROFPAGESOFFSET]);
				double price = Double.parseDouble(result[Hw6Constants.PRICEOFFSET]);
				

			try {
				Book newbook = new Book (title, book1, numOfPages, price);
				System.out.println("Book: " + newbook + "\n");
				bookList.add(newbook);
									
				} 
			catch (BookException e) 
			{
				System.err.println("Cannot make a Book from: " + text + e.getMessage());
			}
			}
			reader.close();
		}
		catch (FileNotFoundException e) 
		{
			System.err.println("Cannot find file: " + Hw6Constants.FILENAME + " " + e.getMessage());
			System.exit(Hw6Constants.CANTFINDFILE);
		} catch (IOException e)
		{
			System.err.println("Cannot read file " + Hw6Constants.FILENAME + " " + e.getMessage());
			System.exit(Hw6Constants.CANTREADFILE);
		}
		
		System.out.println(" ");
		System.out.println("===Book CompareTo method===");
		PriorityQueue<Book> pq = new PriorityQueue<Book>(bookList);
		while(pq.isEmpty() != true)
		{
			System.out.println(pq.poll());
		}
		
		System.out.println(" ");
		System.out.println("===Book Price Comparator===");
		PriorityQueue<Book> pq1 = new PriorityQueue<Book>(bookList.size(), new BookPrice());
		pq1.add(new Book("The Lord of the Rings",BookTypes.HARDBACK,120,29.99));
		pq1.add(new Book("And Then There Were None" ,BookTypes.SOFTBACK,156,19.99));
		pq1.add(new Book("The Hobbit",BookTypes.HARDBACK,212,32.50));
		pq1.add(new Book("The Da Vinci Code",BookTypes.HARDBACK,253,25.00));
		pq1.add(new Book("And Then There Were None",BookTypes.SOFTBACK,156,19.99));
		pq1.add(new Book("Harry Potter and the Half-Blood Prince",BookTypes.ELECTRONIC,439,19.99));
		pq1.add(new Book("And Then There Were None",BookTypes.HARDBACK,156,39.99));
		pq1.add(new Book("The Soloman Curse",BookTypes.HARDBACK,829,23.95));
		pq1.add(new Book("American Sniper",BookTypes.HARDBACK,320,16.20));
		pq1.add(new Book("The Girl on the Train",BookTypes.SOFTBACK,391,23.87));

		 while(pq1.isEmpty() != true)
		 {
			System.out.println(pq1.poll());
		 }
		
	}

}

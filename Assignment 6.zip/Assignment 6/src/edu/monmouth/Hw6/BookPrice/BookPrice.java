package edu.monmouth.Hw6.BookPrice;

import java.util.Comparator;

import edu.monmouth.cs205.book.Book;

public class BookPrice implements Comparator<Book>
{

	@Override
	public int compare(Book o1, Book o2) 
	{
		System.out.println("In Price Comparator...");
		double price1 = o1.getPrice();
		double price2 = o2.getPrice();
		return Double.compare(price1 , price2);
		
	}

}

package edu.monmouth.Hw6;


public class Hw6Constants 
{
	public static final int REQUIRED_PARAMETERS = 1;
	public static final int PARAMETERS_EXIT = -9;
	public static final String LOG_FILE_PROPERTIES_NAME = "log_file_name";
	public static final int PROPERTIES_FILE_EXIT = -10;
	public static final int LOG_FILE_EXIT = -11;


	public static String FILENAME = "books.txt";

	public static String SEPARATOR = ",";

	public static int TITLEOFFSET = 0;
	public static int BOOKTYPEOFFSET = 1;
	public static int NUMBEROFPAGESOFFSET = 2;
	public static int PRICEOFFSET = 3;

	public static int CANTFINDFILE = -12;
	public static int CANTREADFILE = -13;
	
	
}

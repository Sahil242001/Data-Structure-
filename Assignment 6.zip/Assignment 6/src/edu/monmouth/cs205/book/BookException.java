package edu.monmouth.cs205.book;

public class BookException extends Exception
{
	public BookException()
	{
		super();
	}
	
	public BookException(String msg)
	{
		super(msg);
	}
}

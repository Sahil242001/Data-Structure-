package edu.monmouth.cs205.book;

public enum BookTypes 
{
	HARDBACK,
	SOFTBACK,
	ELECTRONIC;
}

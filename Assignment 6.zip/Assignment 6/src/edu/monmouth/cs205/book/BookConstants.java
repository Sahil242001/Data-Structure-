package edu.monmouth.cs205.book;

public class BookConstants 
{
	public static final int MINTITLELENGTH = 1;
	public static final int MINPAGELENGTH = 1;
	public static final int MINPRICE = 0;
}
